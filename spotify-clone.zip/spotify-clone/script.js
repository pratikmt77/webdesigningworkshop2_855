// ===== DATA =====

const songs = [
  { id: 1,  title: "Blinding Lights",     artist: "The Weeknd",      album: "After Hours",       duration: 200, emoji: "🌃", color: "#e8112d" },
  { id: 2,  title: "Shape of You",        artist: "Ed Sheeran",      album: "÷ (Divide)",        duration: 234, emoji: "💚", color: "#169c46" },
  { id: 3,  title: "Stay",                artist: "The Kid LAROI",    album: "F*ck Love 3",       duration: 141, emoji: "🔥", color: "#f59b23" },
  { id: 4,  title: "Levitating",          artist: "Dua Lipa",        album: "Future Nostalgia",  duration: 203, emoji: "✨", color: "#9b59b6" },
  { id: 5,  title: "Peaches",             artist: "Justin Bieber",   album: "Justice",           duration: 198, emoji: "🍑", color: "#e67e22" },
  { id: 6,  title: "MONTERO",             artist: "Lil Nas X",       album: "MONTERO",           duration: 137, emoji: "🤘", color: "#c0392b" },
  { id: 7,  title: "Good 4 U",            artist: "Olivia Rodrigo",  album: "SOUR",              duration: 178, emoji: "💜", color: "#8e44ad" },
  { id: 8,  title: "Heat Waves",          artist: "Glass Animals",   album: "Dreamland",         duration: 238, emoji: "🌊", color: "#1abc9c" },
  { id: 9,  title: "drivers license",     artist: "Olivia Rodrigo",  album: "SOUR",              duration: 242, emoji: "🚗", color: "#3498db" },
  { id: 10, title: "Leave The Door Open", artist: "Bruno Mars",      album: "An Evening With Silk Sonic", duration: 217, emoji: "🎷", color: "#d4ac0d" },
  { id: 11, title: "positions",           artist: "Ariana Grande",   album: "positions",         duration: 172, emoji: "🌸", color: "#ff69b4" },
  { id: 12, title: "Dynamite",            artist: "BTS",             album: "BE",                duration: 199, emoji: "💥", color: "#2980b9" },
  { id: 13, title: "Save Your Tears",     artist: "The Weeknd",      album: "After Hours Remix", duration: 215, emoji: "😢", color: "#e74c3c" },
  { id: 14, title: "Butter",              artist: "BTS",             album: "Butter",            duration: 164, emoji: "🧈", color: "#f1c40f" },
  { id: 15, title: "Mood",               artist: "24kGoldn",        album: "El Dorado",         duration: 141, emoji: "😤", color: "#e67e22" },
  { id: 16, title: "Watermelon Sugar",    artist: "Harry Styles",    album: "Fine Line",         duration: 174, emoji: "🍉", color: "#27ae60" },
];

const playlists = [
  { id: 1,  name: "Liked Songs",       emoji: "💜", songs: [1,2,3,4,5],        type: "playlist" },
  { id: 2,  name: "Top Hits 2024",     emoji: "🔥", songs: [1,3,6,7,8],        type: "playlist" },
  { id: 3,  name: "Chill Vibes",       emoji: "🌊", songs: [8,9,10,16],        type: "playlist" },
  { id: 4,  name: "Workout Mix",       emoji: "💪", songs: [1,6,7,12,15],      type: "playlist" },
  { id: 5,  name: "K-Pop Hits",        emoji: "🎵", songs: [12,14],            type: "playlist" },
  { id: 6,  name: "Pop Favourites",    emoji: "⭐", songs: [2,4,5,11,13,16],  type: "playlist" },
];

const genres = [
  { name: "Pop",         color: "#e91429" },
  { name: "Hip-Hop",     color: "#608108" },
  { name: "Dance/EDM",   color: "#0d73ec" },
  { name: "R&B",         color: "#8d67ab" },
  { name: "Indie",       color: "#ba5d07" },
  { name: "Rock",        color: "#148a08" },
  { name: "Podcast",     color: "#006450" },
  { name: "Lo-Fi",       color: "#0d73ec" },
  { name: "Bollywood",   color: "#c62e65" },
  { name: "Classical",   color: "#8d67ab" },
  { name: "Metal",       color: "#1e3264" },
  { name: "Jazz",        color: "#ba5d07" },
];

// ===== PLAYER STATE =====
let currentSongIndex = 0;
let isPlaying = false;
let isShuffle = false;
let isRepeat = false;
let currentPlaylist = [...songs];
let likedSongs = new Set(JSON.parse(localStorage.getItem("sp-liked") || "[]"));
let progressInterval = null;
let fakeCurrentTime = 0;
let fakeDuration = 0;

// ===== INIT =====
document.addEventListener("DOMContentLoaded", () => {
  setGreeting();
  renderQuickPlay();
  renderFeatured();
  renderAlbums();
  renderRecent();
  renderPlaylistSidebar();
  renderGenres();
  renderLibrary();
  updateLikeBtn();
});

function setGreeting() {
  const h = new Date().getHours();
  const el = document.getElementById("home-greeting");
  if (!el) return;
  if (h < 12) el.textContent = "Good morning";
  else if (h < 18) el.textContent = "Good afternoon";
  else el.textContent = "Good evening";
}

// ===== SECTION SWITCHING =====
function showSection(name) {
  ["home","search","library"].forEach(s => {
    const el = document.getElementById("section-" + s);
    if (el) el.style.display = (s === name ? "" : "none");
  });
  document.querySelectorAll(".nav-link").forEach(link => link.classList.remove("active"));
  const map = { home: 0, search: 1, library: 2 };
  const links = document.querySelectorAll(".nav-link");
  if (links[map[name]]) links[map[name]].classList.add("active");
  if (name === "search") setTimeout(() => document.getElementById("search-input")?.focus(), 100);
}

// ===== RENDER HOME QUICK PLAY =====
function renderQuickPlay() {
  const grid = document.getElementById("quick-play-grid");
  if (!grid) return;
  grid.innerHTML = playlists.slice(0, 6).map(p => `
    <div class="quick-card" onclick="playPlaylist(${p.id})">
      <div class="quick-card-art" style="background:${getGradient(p.id)}">${p.emoji}</div>
      <span class="quick-card-name">${p.name}</span>
      <button class="quick-play-btn" onclick="event.stopPropagation();playPlaylist(${p.id})">
        <svg viewBox="0 0 24 24" fill="currentColor" width="18" height="18"><path d="M8 5v14l11-7z"/></svg>
      </button>
    </div>
  `).join("");
}

function getGradient(seed) {
  const colors = ["#5038a0","#1e3264","#148a08","#8d67ab","#e91429","#0d73ec","#ba5d07","#006450"];
  return colors[seed % colors.length];
}

// ===== RENDER FEATURED / ALBUMS / RECENT =====
function renderFeatured() {
  renderCardRow("featured-row", playlists.slice(0, 5), "playlist");
}

function renderAlbums() {
  const albums = [...new Map(songs.map(s => [s.album, s])).values()].slice(0, 6);
  renderCardRow("albums-row", albums, "album");
}

function renderRecent() {
  renderCardRow("recent-row", songs.slice(0, 6), "song");
}

function renderCardRow(containerId, items, type) {
  const el = document.getElementById(containerId);
  if (!el) return;
  el.innerHTML = items.map((item, i) => {
    const emoji = item.emoji || "🎵";
    const title = item.title || item.name || item.album;
    const sub = item.artist || (item.songs ? item.songs.length + " songs" : "");
    const color = item.color || getGradient(i);
    return `
      <div class="music-card" onclick="handleCardClick('${type}', ${item.id || i})">
        <div class="card-art" style="background:${color}">
          <span>${emoji}</span>
          <button class="card-play-btn" onclick="event.stopPropagation();handleCardClick('${type}', ${item.id || i})">
            <svg viewBox="0 0 24 24" fill="currentColor" width="22" height="22"><path d="M8 5v14l11-7z"/></svg>
          </button>
        </div>
        <div class="card-title">${title}</div>
        <div class="card-sub">${sub}</div>
      </div>
    `;
  }).join("");
}

function handleCardClick(type, id) {
  if (type === "playlist") playPlaylist(id);
  else if (type === "song") playSong(id - 1, songs);
  else if (type === "album") {
    const albumName = songs[id]?.album;
    const albumSongs = songs.filter(s => s.album === albumName);
    playSong(0, albumSongs);
  }
}

// ===== PLAYLIST SIDEBAR =====
function renderPlaylistSidebar() {
  const ul = document.getElementById("playlist-sidebar-list");
  if (!ul) return;
  ul.innerHTML = playlists.map(p => `
    <li onclick="playPlaylist(${p.id})">${p.emoji} ${p.name}</li>
  `).join("");
}

function playPlaylist(playlistId) {
  const pl = playlists.find(p => p.id === playlistId);
  if (!pl) return;
  const playlistSongs = pl.songs.map(sid => songs.find(s => s.id === sid)).filter(Boolean);
  playSong(0, playlistSongs);
}

function createPlaylist() {
  const name = prompt("Playlist name:");
  if (name) {
    const id = playlists.length + 1;
    playlists.push({ id, name, emoji: "🎵", songs: [], type: "playlist" });
    renderPlaylistSidebar();
    renderLibrary();
  }
}

// ===== SEARCH =====
function doSearch(query) {
  const container = document.getElementById("search-results");
  if (!container) return;

  if (!query.trim()) {
    container.innerHTML = `<h2 style="color:#fff;margin-bottom:20px;padding:0 24px">Browse all genres</h2><div class="genre-grid" id="genre-grid"></div>`;
    renderGenres();
    return;
  }

  const q = query.toLowerCase();
  const results = songs.filter(s =>
    s.title.toLowerCase().includes(q) ||
    s.artist.toLowerCase().includes(q) ||
    s.album.toLowerCase().includes(q)
  );

  container.innerHTML = `
    <div class="search-tracks">
      <h2>Songs</h2>
      ${results.length === 0
        ? `<p style="color:#b3b3b3;padding:20px 0">No results for "<strong>${query}</strong>"</p>`
        : results.map((s, i) => `
          <div class="track-row ${currentPlaylist[currentSongIndex]?.id === s.id && isPlaying ? 'playing' : ''}" onclick="playSong(${songs.indexOf(s)}, songs)">
            <span class="track-num">${currentPlaylist[currentSongIndex]?.id === s.id && isPlaying ? '🔊' : i+1}</span>
            <div class="track-art" style="background:${s.color}">${s.emoji}</div>
            <div class="track-info">
              <div class="track-title">${s.title}</div>
              <div class="track-artist">${s.artist}</div>
            </div>
            <span class="track-duration">${formatTime(s.duration)}</span>
          </div>
        `).join("")
      }
    </div>
  `;
}

// ===== GENRES =====
function renderGenres() {
  const grid = document.getElementById("genre-grid");
  if (!grid) return;
  grid.innerHTML = genres.map(g => `
    <div class="genre-card" style="background:${g.color}" onclick="searchGenre('${g.name}')">
      ${g.name}
    </div>
  `).join("");
}

function searchGenre(name) {
  const input = document.getElementById("search-input");
  if (input) {
    input.value = name;
    doSearch(name);
  }
}

// ===== LIBRARY =====
function renderLibrary() {
  const el = document.getElementById("library-list");
  if (!el) return;
  el.innerHTML = playlists.map(p => {
    const count = p.songs.length;
    return `
      <div class="lib-item" onclick="playPlaylist(${p.id})">
        <div class="lib-art" style="background:${getGradient(p.id)}">${p.emoji}</div>
        <div class="lib-info">
          <div class="lib-name">${p.name}</div>
          <div class="lib-sub">Playlist · ${count} song${count !== 1 ? 's' : ''}</div>
        </div>
      </div>
    `;
  }).join("") + `
    <div class="lib-item" onclick="showLiked()">
      <div class="lib-art" style="background:#8d67ab">💜</div>
      <div class="lib-info">
        <div class="lib-name">Liked Songs</div>
        <div class="lib-sub">Playlist · ${likedSongs.size} song${likedSongs.size !== 1 ? 's' : ''}</div>
      </div>
    </div>
  `;
}

function showLiked() {
  const liked = songs.filter(s => likedSongs.has(s.id));
  if (liked.length) playSong(0, liked);
}

// ===== PLAYER =====
function playSong(index, playlist) {
  currentPlaylist = playlist || songs;
  currentSongIndex = index;
  const song = currentPlaylist[currentSongIndex];
  if (!song) return;

  isPlaying = true;
  fakeCurrentTime = 0;
  fakeDuration = song.duration;

  // Update now playing UI
  document.getElementById("np-title").textContent = song.title;
  document.getElementById("np-artist").textContent = song.artist;

  const artEl = document.getElementById("np-art");
  artEl.textContent = song.emoji;
  artEl.style.background = song.color;
  artEl.classList.add("has-song");

  document.getElementById("time-total").textContent = formatTime(fakeDuration);
  updatePlayPauseBtn();
  updateLikeBtn();
  startProgress();

  // Highlight currently playing track in search
  doSearch(document.getElementById("search-input")?.value || "");
}

function togglePlay() {
  if (!currentPlaylist[currentSongIndex]) return;
  isPlaying = !isPlaying;
  updatePlayPauseBtn();
  if (isPlaying) startProgress();
  else stopProgress();
}

function updatePlayPauseBtn() {
  const pi = document.getElementById("play-icon");
  const pa = document.getElementById("pause-icon");
  if (pi) pi.style.display = isPlaying ? "none" : "";
  if (pa) pa.style.display = isPlaying ? "" : "none";
}

function prevSong() {
  if (fakeCurrentTime > 3) {
    fakeCurrentTime = 0;
    return;
  }
  currentSongIndex = (currentSongIndex - 1 + currentPlaylist.length) % currentPlaylist.length;
  playSong(currentSongIndex, currentPlaylist);
}

function nextSong() {
  if (isShuffle) {
    currentSongIndex = Math.floor(Math.random() * currentPlaylist.length);
  } else {
    currentSongIndex = (currentSongIndex + 1) % currentPlaylist.length;
  }
  playSong(currentSongIndex, currentPlaylist);
}

function toggleShuffle() {
  isShuffle = !isShuffle;
  document.getElementById("shuffle-btn").classList.toggle("active", isShuffle);
}

function toggleRepeat() {
  isRepeat = !isRepeat;
  document.getElementById("repeat-btn").classList.toggle("active", isRepeat);
}

function toggleLike() {
  const song = currentPlaylist[currentSongIndex];
  if (!song) return;
  if (likedSongs.has(song.id)) likedSongs.delete(song.id);
  else likedSongs.add(song.id);
  localStorage.setItem("sp-liked", JSON.stringify([...likedSongs]));
  updateLikeBtn();
  renderLibrary();
}

function updateLikeBtn() {
  const btn = document.getElementById("like-btn");
  const song = currentPlaylist[currentSongIndex];
  if (btn && song) btn.classList.toggle("liked", likedSongs.has(song.id));
}

function setVolume(val) {
  // Visual only — updates slider fill
  const slider = document.getElementById("volume-slider");
  if (slider) {
    const pct = val / 100;
    slider.style.background = `linear-gradient(to right, #fff ${pct*100}%, #4d4d4d ${pct*100}%)`;
  }
}

function seekTo(event) {
  const track = document.getElementById("progress-track");
  if (!track || !fakeDuration) return;
  const rect = track.getBoundingClientRect();
  const pct = Math.max(0, Math.min(1, (event.clientX - rect.left) / rect.width));
  fakeCurrentTime = pct * fakeDuration;
  updateProgressUI();
}

// ===== PROGRESS SIMULATION =====
function startProgress() {
  stopProgress();
  progressInterval = setInterval(() => {
    if (!isPlaying) return;
    fakeCurrentTime += 1;
    if (fakeCurrentTime >= fakeDuration) {
      if (isRepeat) fakeCurrentTime = 0;
      else { nextSong(); return; }
    }
    updateProgressUI();
  }, 1000);
}

function stopProgress() {
  if (progressInterval) { clearInterval(progressInterval); progressInterval = null; }
}

function updateProgressUI() {
  const fill = document.getElementById("progress-fill");
  const cur = document.getElementById("time-current");
  if (!fill || !cur) return;
  const pct = fakeDuration ? (fakeCurrentTime / fakeDuration) * 100 : 0;
  fill.style.width = pct + "%";
  cur.textContent = formatTime(fakeCurrentTime);
}

// ===== UTILS =====
function formatTime(seconds) {
  const m = Math.floor(seconds / 60);
  const s = Math.floor(seconds % 60);
  return `${m}:${s.toString().padStart(2, "0")}`;
}

// Init volume slider bg
window.addEventListener("load", () => setVolume(80));
